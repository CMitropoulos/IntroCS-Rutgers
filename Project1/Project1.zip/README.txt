How to run the code
- After running the make file, please use the following command to run the code
-./[executable] [inputFileName]
EX: ./partA 10Numbers.txt
- The output is then written to the results_[outputFileName].txt
